-----------------------
/*Insert of ActualTestingHours in CONTROLTESTING*/
ALTER TABLE [dbo].[CONTROLTESTING] ADD [ActualTestingHours] Integer NULL
---------------------------
/*Insert of PlannedTestingHours in CTRLTESTINGSCRIPT*/
ALTER TABLE [dbo].[CTRLTESTINGSCRIPT] ADD [PlannedTestingHours] Integer NULL