--Step Creation of the new field in the necessary tables
Alter Table CHARTTESTINGCRITERIA
	Add  PlannedTestingHours Int Null;

Alter Table CHARTTESTINGCRITERIA
Add  ActualTestingHours Int Null;

--Step Population of Tables for consiguration in permissions and roles

/*Actual Testing Hours Field*/
/*Query 1 to create new element Actual Testing Hours*/
INSERT INTO ELEMENT
SELECT a.ClientID, 'Actual Testing Hours', b.ElementType, a.Active, b.CreateDate, b.CreatedBy, b.EditDate, b.EditedBy, b.ElementGroup, b.IsRiskDomainElement FROM [dbo].CLIENT a ,
(SELECT *
  FROM [dbo].[ELEMENT] where ElementName = 'Selection Methodology' and ClientID = 4) b
  where a.Active = 1;

/*Query 2 to create new element Actual Testing Hours*/
INSERT INTO ELEMENTHIERARCHY
  select a.ClientID, b.ElementID, a.ParentID,a.Depth, a.DisplayOrder, a.Active, a.CreateDate, a.CreatedBy, a.EditDate, a.EditedBy from 
  (select * from ELEMENTHIERARCHY where ElementID 
  in (select ElementID from ELEMENT where ElementName = 'Selection Methodology')) as a join 
  ELEMENT b on a.ClientID = b.ClientID where b.ElementName = 'Actual Testing Hours';

-------------------------------

/*Planned Testing Hours Field*/
/*Query 1 to create new element Planned Testing Hours*/
INSERT INTO ELEMENT
SELECT a.ClientID, 'Planned Testing Hours', b.ElementType, a.Active, b.CreateDate, b.CreatedBy, b.EditDate, b.EditedBy, b.ElementGroup, b.IsRiskDomainElement FROM [dbo].CLIENT a ,
(SELECT *
  FROM [dbo].[ELEMENT] where ElementName = 'Independent Testing Population Size' and ClientID = 4) b
  where a.Active = 1;

    /* Query 2 to create new element Planned Testing Hours*/
  INSERT INTO ELEMENTHIERARCHY
  select a.ClientID, b.ElementID, a.ParentID,a.Depth, a.DisplayOrder, a.Active, a.CreateDate, a.CreatedBy, a.EditDate, a.EditedBy from 
  (select * from ELEMENTHIERARCHY where ElementID 
  in (select ElementID from ELEMENT where ElementName = 'Independent Testing Population Size')) as a join 
  ELEMENT b on a.ClientID = b.ClientID where b.ElementName = 'Planned Testing Hours';

/*To complete the set up of Planned Testing Hours run the following scripts attached to the task  
  "Inserts For Selection Criteria and History.sql" / "InsertsFieldsInControlTables.sql"
  if the current database doesn't have the necessary columns*/