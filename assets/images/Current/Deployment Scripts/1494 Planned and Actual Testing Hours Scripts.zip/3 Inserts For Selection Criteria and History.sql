/*Insert of PlannedTestingHours in CTRLTESTINGSCRIPTBAK*/
ALTER TABLE [dbo].[CTRLTESTINGSCRIPTBAK] ADD [PlannedTestingHours] Integer NULL

/*Insert of PlannedTestingHours in [CTRLTESTINGSCRIPTHISTORY]*/
ALTER TABLE [dbo].[CTRLTESTINGSCRIPTHISTORY] ADD [PlannedTestingHours] Integer NULL

/*Insert of PlannedTestingHours in [CONTROLTESTINGCRITERIA]*/
ALTER TABLE [dbo].[CONTROLTESTINGCRITERIA] ADD [PlannedTestingHours] Integer NULL
ALTER TABLE [dbo].[CONTROLTESTINGCRITERIA] ADD [ActualTestingHours] Integer NULL


/*Insert of PlannedTestingHours and ActualTestingHours into [CODELIST]*/
INSERT INTO [dbo].[CODELIST] (ClientID, PeriodID, GroupName, CodeKey, CodeValue, Active, CreateDate, CreatedBy, EditDate, EditedBy)
Values (NULL, NULL,'ActualTestingHours','1','Yes',1, GETDATE(),2109,GETDATE(),2109)

INSERT INTO [dbo].[CODELIST] (ClientID, PeriodID, GroupName, CodeKey, CodeValue, Active, CreateDate, CreatedBy, EditDate, EditedBy)
Values (NULL, NULL,'ActualTestingHours','0','No',1, GETDATE(),2109,GETDATE(),2109)

INSERT INTO [dbo].[CODELIST] (ClientID, PeriodID, GroupName, CodeKey, CodeValue, Active, CreateDate, CreatedBy, EditDate, EditedBy)
Values (NULL, NULL,'PlannedTestingHours','1','Yes',1, GETDATE(),2109,GETDATE(),2109)

INSERT INTO [dbo].[CODELIST] (ClientID, PeriodID, GroupName, CodeKey, CodeValue, Active, CreateDate, CreatedBy, EditDate, EditedBy)
Values (NULL, NULL,'PlannedTestingHours','0','No',1, GETDATE(),2109,GETDATE(),2109)