
-- Roll Back Creation of the new field in the necessary tables
Alter Table CHARTTESTINGCRITERIA
	Drop Column  PlannedTestingHours;

Alter Table CHARTTESTINGCRITERIA
	Drop Column  ActualTestingHours;
	
-- Roll Back Population of Tables for consiguration in permissions and roles
/*Actual Testing Hours Field*/
Delete From [ELEMENTHIERARCHY] where ElementID In (
Select 
	ElementID
From [Element] 
Where ElementName = 'Actual Testing Hours'
	And ClientID IS Not Null And Active = 1
);

Delete From [ELEMENT] Where ElementName = 'Actual Testing Hours';
------------------------------------------------------------
/*Planned Testing Hours Field*/
Delete From [ELEMENTHIERARCHY] where ElementID In (
Select 
	ElementID
From [Element] 
Where ElementName = 'Planned Testing Hours'
	And ClientID IS Not Null And Active = 1
);

Delete From [ELEMENT] Where ElementName = 'Planned Testing Hours';