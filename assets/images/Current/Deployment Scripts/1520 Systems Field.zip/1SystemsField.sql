/* Change capacity of column field for n characters*/
ALTER TABLE [dbo].[CONTROL]
ALTER COLUMN SystemID nvarchar(max);

/* Change capacity of column field for n characters*/
ALTER TABLE [dbo].[CONTROLBAK]
ALTER COLUMN SystemID nvarchar(max);
