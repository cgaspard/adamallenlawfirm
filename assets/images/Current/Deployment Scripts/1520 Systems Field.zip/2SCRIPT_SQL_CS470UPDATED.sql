-- INIT SCRIPTS

-- SCRIPT 1 [OK].
/*
AUTHOR:			ALEJANDRO JUNQUI 
DATE:			13-12-2021
TASK:			CS-470 "Systems"
DESCRIPCION:	DELETING SYSTEMS IN ELEMENTHIERARCHY (DETAIL).
*/
DELETE FROM ELEMENTHIERARCHY
WHERE HierarchyID IN (SELECT
    HierarchyID
  FROM ELEMENTHIERARCHY
  WHERE ElementID IN (SELECT
    ElementID
  FROM [dbo].[ELEMENT]
  WHERE elementname = 'Systems'));
-- SCRIPT 2 [OK].
/*
AUTHOR:			ALEJANDRO JUNQUI 
DATE:			13-12-2021
TASK:			CS-470 "Systems"
DESCRIPCION:	DELETING SYSTEMS IN ELEMENT (HEADER).
*/
DELETE FROM ELEMENT
WHERE ElementID IN (SELECT
    ElementID
  FROM [dbo].[ELEMENT]
  WHERE elementname = 'Systems');

-- SCRIPT 3 [OK].
/*
AUTHOR:			ALEJANDRO JUNQUI 
DATE:			12-11-2021
TASK:			CS-470 "Systems"
DESCRIPCION:	INSERT THE OPTION "SYSTEMS" FOR ALL CLIENTS ACTIVES AGAIN.
*/
DECLARE @PIVOT_DATE datetime = '2021-01-01';
INSERT INTO ELEMENT
SELECT A.CLIENTID, 'Systems' 'ELEMENTNAME', B.ELEMENTTYPE, A.ACTIVE, @PIVOT_DATE 'CREATEDATE', 1 'CREATEDBY', @PIVOT_DATE 'EDITDATE', 1 'EDITEDBY', B.ELEMENTGROUP, B.ISRISKDOMAINELEMENT FROM [DBO].CLIENT A ,
(SELECT TOP 1 * FROM [DBO].[ELEMENT] WHERE ELEMENTNAME = 'Control') B WHERE A.ACTIVE = 1;

-- SCRIPT 4 [OK]
/*
AUTHOR:			ALEJANDRO JUNQUI 
DATE:			12-11-2021
TASK:			CS-470 "Systems"
DESCRIPCION:	RELATE THE OPTION "Systems" (child) INTO THE PARENT ELEMENT "Control" FOR ALL CLIENTS.
*/
DECLARE @CREATE_EDIT_DATE datetime = '2021-01-01'
DECLARE @Index_C int = 0
DECLARE @ParentID_C int
DECLARE @PractitionerId int
DECLARE @ElementID_C int
DECLARE @Exist_C int
DECLARE MY_CURSOR CURSOR 
  LOCAL STATIC READ_ONLY FORWARD_ONLY
FOR 
SELECT DISTINCT ClientID 
FROM CLIENT where Active = 1;

OPEN MY_CURSOR
FETCH NEXT FROM MY_CURSOR INTO @PractitionerId
WHILE @@FETCH_STATUS = 0
BEGIN 
	PRINT '********************************** INIT **************************************************'
	
    --INSERT Control
	SET @ParentID_C = 0;
	SELECT TOP 1 @ElementID_C = ElementID from [DBO].[ELEMENT] where ElementName = 'Control' and ClientID = @PractitionerId and Active = 1;
	SET @ParentID_C = @ElementID_C;
	IF @ParentID_C > 0 
	BEGIN
		SELECT TOP 1 @Exist_C = HierarchyID from [DBO].[ELEMENTHIERARCHY] where ElementID = @ElementID_C and ClientID = @PractitionerId and Active = 1 and ParentID = 0;
		IF(@Exist_C > 0) 
		BEGIN
			PRINT 'ALREADY EXIST Control ' + CAST(@ElementID_C AS VARCHAR)
		END
		ELSE 
		BEGIN
			IF @ElementID_C = 0
			BEGIN
				PRINT 'DON NOT EXIST ELEMENT Control. IT IS NOT POSIBLE THE INSERT'
			END
			ELSE
			BEGIN
				PRINT 'INSERTING Control: CLIENTID ' + cast(@PractitionerId as varchar) + ' ELEMENTID ' +  cast(@ElementID_C as varchar)  + ' PARENTID 0 DEPT 1 ORDER 1'
				INSERT INTO [dbo].[ELEMENTHIERARCHY](ClientId, ElementID, ParentID, Depth, DisplayOrder, Active, CreateDate, CreatedBy, EditDate, EditedBy) 
				VALUES (@PractitionerId, @ElementID_C, 0, 1, 1, 1, @CREATE_EDIT_DATE, 1,@CREATE_EDIT_DATE, 1);
			END
		END
		--INSERT SYSTEMS
		SET @Exist_C = 0;
		SET @ElementID_C = 0;
		SELECT TOP 1 @ElementID_C = ElementID from [DBO].[ELEMENT] where ElementName = 'Systems' and ClientID = @PractitionerId and Active = 1;
		SELECT TOP 1 @Exist_C = HierarchyID from [DBO].[ELEMENTHIERARCHY] where ElementID = @ElementID_C and ClientID = @PractitionerId and ParentID = @ParentID_C and Active = 1;
		IF(@Exist_C > 0) 
		BEGIN
			PRINT 'ALREADY EXIST Systems ' + CAST(@PractitionerId AS VARCHAR)
		END
		ELSE 
		BEGIN
			IF @ElementID_C = 0
			BEGIN
				PRINT 'DON NOT EXIST ELEMENT Systems. IT IS NOT POSIBLE THE INSERT'
			END
			ELSE
			BEGIN
				PRINT 'INSERTING Systems: CLIENTID '+ cast(@PractitionerId as varchar)  +' ELEMENTID ' + cast(@ElementID_C as varchar) + ' PARENTID '+cast(@ParentID_C as varchar)+' DEPT 2 ORDER 1'
				INSERT INTO [dbo].[ELEMENTHIERARCHY](ClientId, ElementID, ParentID, Depth, DisplayOrder, Active, CreateDate, CreatedBy, EditDate, EditedBy) 
				VALUES (@PractitionerId, @ElementID_C, @ParentID_C, 2, 1, 1, @CREATE_EDIT_DATE, 1,@CREATE_EDIT_DATE, 1);
			END
		END

		
	END
	ELSE
	BEGIN
		PRINT 'THE MAIN ELEMENT NOT FOUNDED ' + CAST(@PractitionerId as varchar)
	END
    
	PRINT '**************************************** END ********************************************'
	SET @EXIST_C = 0;
	SET @ELEMENTID_C = 0;
	SET @Index_C = @Index_C + 1;
    FETCH NEXT FROM MY_CURSOR INTO @PractitionerId
END
CLOSE MY_CURSOR
DEALLOCATE MY_CURSOR
PRINT CAST(@Index_C as varchar) + ' LOOPS'

-- END SCRIPTS
