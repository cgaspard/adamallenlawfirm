/*Queries to restore original capacity*/

/* Change to original capacity*/
ALTER TABLE [dbo].[CONTROL]
ALTER COLUMN SystemID nvarchar(20);


/* Change to original capacity*/
ALTER TABLE [dbo].[CONTROLBAK]
ALTER COLUMN SystemID nvarchar(20);